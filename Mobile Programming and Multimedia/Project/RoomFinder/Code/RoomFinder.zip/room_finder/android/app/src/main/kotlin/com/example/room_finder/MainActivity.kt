package com.example.room_finder

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
