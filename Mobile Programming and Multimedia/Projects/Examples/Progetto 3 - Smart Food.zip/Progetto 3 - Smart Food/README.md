# Smart_Food
Project of "[Mobile Programming and Multimedia](https://www.didattica.unipd.it/off/2021/LM/SC/SC2598/000ZZ/SCP7080184/N0)" course - UNIPD, A.Y. 2021/22

**Smart Food** is a cross-platform mobile application for Android and iOS created with Flutter framework. Its aim is to allow to the users creating recipes and managing their alimentary plan.

Authors: 
- Alberto Gobbo
- Marco Nardelotto
