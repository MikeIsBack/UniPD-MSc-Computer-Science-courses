abstract class Food {
  String getName();
  String getAdditionalDetail();
  Map<String, dynamic> toMap();
}
