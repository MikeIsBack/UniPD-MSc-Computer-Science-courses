import requests
import json
import pandas as pd
from matplotlib import pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.colors import ListedColormap
import seaborn as sns
import numpy as np

def get_uplinks(api_key, application_id, device_id=None, limit=10, after="2020-08-20T00:00:00Z", field_mask=None):
    # Base URL for the API
    base_url = f"https://eu1.cloud.thethings.network/api/v3/as/applications/{application_id}/packages/storage/uplink_message"
    
    # If retrieving uplinks for a specific device, modify the URL
    if device_id:
        base_url = f"https://eu1.cloud.thethings.network/api/v3/as/applications/{application_id}/devices/{device_id}/packages/storage/uplink_message"
    
    # Set the HTTP headers including the Authorization header with the API key
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Accept": "application/json"  # You can use 'text/event-stream' if needed for streaming
    }
    
    # Define the parameters (query string) for the request
    params = {
        "limit": limit,
        "after": after
    }
    
    # Optionally add a field mask to retrieve specific fields
    if field_mask:
        params["field_mask"] = field_mask
    
    # Make the GET request to the API
    response = requests.get(base_url, headers=headers, params=params)
    
    # Raise an exception if the request failed
    if response.status_code != 200:
        raise Exception(f"Error {response.status_code}: {response.text}")
    
    # Return the response data in JSON format
    response = response.content.decode("utf-8")
    objs = []
    for line in response.split("\n"):
        if line.strip():
            objs.append(json.loads(line))
    return objs

# Example usage
api_key = ""
application_id = ""
device_id = None # Optional; set to None if you want all devices
limit = 100
after = "2024-11-11T14:54:52Z"
field_mask = "up.uplink_message.decoded_payload"  # Optional; to retrieve specific fields
uplink_data = get_uplinks(api_key, application_id, device_id, limit, after, field_mask)
data = []
for d in uplink_data:
    try:
        dd = d["result"]["uplink_message"]["decoded_payload"]
        data.append(dd)
    except:
        pass
    # print(json.dumps(d, indent=2))

df = pd.DataFrame(data)

print(df)
