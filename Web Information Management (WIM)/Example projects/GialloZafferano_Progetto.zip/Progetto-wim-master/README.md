# Progetto-wim
Progetto per il corso Web Information Management del corso di laurea in informatica presso UNIPD.
Il progetto consiste nell'analisi di usabilità del sito https://www.giallozafferano.it.
